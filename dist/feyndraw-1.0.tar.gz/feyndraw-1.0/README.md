# Purpose
This is a package designed to draw Feynman diagrams (using Matplotlib) with a possibility of customizing pretty much anything you want.

# Documentation
Instead of providing detailes documentation, there is an example.py file and comments around the functions in the .py files. Feel free to discover all the customization you can do by pattern matching and playing with the parameters! Visit the repository on [GitHub](https://github.com/schhug/feyndraw).

# Install
Install with `pip install feyndraw`.